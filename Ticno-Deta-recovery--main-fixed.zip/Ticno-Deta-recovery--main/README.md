# Ticno Deta Recovery

Android application to recover deleted:
- Videos (MP4, 3GP, MKV)
- Photos (JPG, PNG)
- Audio (MP3, WAV)
- Documents (PDF, DOC)

## Features
1. Multi-format support
2. Deep scan technology
3. Preview before recovery
4. Simple UI

## Installation
1. Clone this repository
2. Open in Android Studio
3. Build and run
