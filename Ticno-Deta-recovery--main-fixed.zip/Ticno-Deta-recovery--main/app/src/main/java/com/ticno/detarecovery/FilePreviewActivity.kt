class FilePreviewActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityFilePreviewBinding
    private lateinit var filePath: String
    private lateinit var fileType: String
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityFilePreviewBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        filePath = intent.getStringExtra("file_path") ?: return
        fileType = intent.getStringExtra("file_type") ?: return
        
        setupViews()
        loadFilePreview()
    }
    
    private fun setupViews() {
        binding.buttonRecover.setOnClickListener { recoverFile() }
    }
    
    private fun loadFilePreview() {
        when (fileType) {
            "video" -> {
                binding.videoView.visibility = View.VISIBLE
                binding.videoView.setVideoPath(filePath)
                binding.videoView.setOnPreparedListener { mp ->
                    mp.start()
                    val thumb = ThumbnailUtils.createVideoThumbnail(
                        filePath,
                        MediaStore.Images.Thumbnails.MINI_KIND
                    )
                    binding.imagePreview.setImageBitmap(thumb)
                }
            }
            "image" -> {
                binding.imagePreview.visibility = View.VISIBLE
                Glide.with(this).load(filePath).into(binding.imagePreview)
            }
            else -> {
                binding.textPreview.visibility = View.VISIBLE
                if (fileType == "audio") {
                    binding.textPreview.text = "Audio file: ${File(filePath).name}"
                } else {
                    binding.textPreview.text = "Document file: ${File(filePath).name}"
                }
            }
        }
    }
    
    private fun recoverFile() {
        val destinationDir = File(
            Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_DOWNLOADS),
            "TicnoRecovered"
        )
        
        if (!destinationDir.exists()) {
            destinationDir.mkdirs()
        }
        
        val sourceFile = File(filePath)
        val destFile = File(destinationDir, sourceFile.name)
        
        try {
            sourceFile.copyTo(destFile, overwrite = true)
            Toast.makeText(this, "File recovered successfully!", Toast.LENGTH_LONG).show()
        } catch (e: Exception) {
            Toast.makeText(this, "Recovery failed: ${e.message}", Toast.LENGTH_LONG).show()
        }
    }
}
