class RecoveryActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityRecoveryBinding
    private lateinit var adapter: FileRecoveryAdapter
    private val files = mutableListOf<RecoverableFile>()
    private lateinit var fileType: String
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityRecoveryBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        fileType = intent.getStringExtra("file_type") ?: "video"
        setupRecyclerView()
        startScanning()
    }
    
    private fun setupRecyclerView() {
        adapter = FileRecoveryAdapter(files) { file ->
            // Preview file
            val intent = Intent(this, FilePreviewActivity::class.java).apply {
                putExtra("file_path", file.path)
                putExtra("file_type", file.type)
            }
            startActivity(intent)
        }
        
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = adapter
    }
    
    private fun startScanning() {
        binding.progressBar.visibility = View.VISIBLE
        binding.textStatus.text = "Scanning for ${fileType}s..."
        
        CoroutineScope(Dispatchers.IO).launch {
            val scanner = FileScanner(this@RecoveryActivity)
            val foundFiles = scanner.scanForFiles(fileType)
            
            withContext(Dispatchers.Main) {
                files.clear()
                files.addAll(foundFiles)
                adapter.notifyDataSetChanged()
                
                binding.progressBar.visibility = View.GONE
                binding.textStatus.text = "Found ${files.size} ${fileType}s"
            }
        }
    }
}
