class FileRecoveryAdapter(
    private val files: List<RecoverableFile>,
    private val onItemClick: (RecoverableFile) -> Unit
) : RecyclerView.Adapter<FileRecoveryAdapter.ViewHolder>() {

    inner class ViewHolder(val binding: ItemFileBinding) : RecyclerView.ViewHolder(binding.root) {
        fun bind(file: RecoverableFile) {
            binding.textFileName.text = file.name
            binding.textFileSize.text = formatSize(file.size)
            binding.textFileDate.text = formatDate(file.lastModified)
            
            // Set icon based on file type
            val iconRes = when (file.type) {
                "video" -> R.drawable.ic_video
                "image" -> R.drawable.ic_image
                "audio" -> R.drawable.ic_audio
                else -> R.drawable.ic_document
            }
            binding.imageFileIcon.setImageResource(iconRes)
            
            binding.root.setOnClickListener { onItemClick(file) }
        }
        
        private fun formatSize(size: Long): String {
            return when {
                size < 1024 -> "$size B"
                size < 1024 * 1024 -> "${size / 1024} KB"
                size < 1024 * 1024 * 1024 -> "${size / (1024 * 1024)} MB"
                else -> "${size / (1024 * 1024 * 1024)} GB"
            }
        }
        
        private fun formatDate(timestamp: Long): String {
            return SimpleDateFormat("dd MMM yyyy HH:mm", Locale.getDefault())
                .format(Date(timestamp))
        }
    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): ViewHolder {
        val binding = ItemFileBinding.inflate(
            LayoutInflater.from(parent.context),
            parent,
            false
        )
        return ViewHolder(binding)
    }

    override fun onBindViewHolder(holder: ViewHolder, position: Int) {
        holder.bind(files[position])
    }

    override fun getItemCount() = files.size
}
