class FileScanner(private val context: Context) {
    
    fun scanForFiles(fileType: String): List<RecoverableFile> {
        val files = mutableListOf<RecoverableFile>()
        val externalStorage = Environment.getExternalStorageDirectory()
        
        // Common paths to scan
        val scanPaths = arrayOf(
            "${externalStorage.path}/DCIM",
            "${externalStorage.path}/Pictures",
            "${externalStorage.path}/Movies",
            "${externalStorage.path}/Music",
            "${externalStorage.path}/Download",
            "${externalStorage.path}/WhatsApp/Media"
        )
        
        scanPaths.forEach { path ->
            File(path).walkTopDown().forEach { file ->
                if (file.isFile && matchesType(file, fileType)) {
                    files.add(RecoverableFile(
                        path = file.absolutePath,
                        name = file.name,
                        size = file.length(),
                        lastModified = file.lastModified(),
                        type = fileType
                    ))
                }
            }
        }
        
        return files
    }
    
    private fun matchesType(file: File, fileType: String): Boolean {
        return when (fileType) {
            "video" -> file.extension.lowercase() in arrayOf("mp4", "3gp", "mkv", "mov", "avi")
            "image" -> file.extension.lowercase() in arrayOf("jpg", "jpeg", "png", "gif", "webp")
            "audio" -> file.extension.lowercase() in arrayOf("mp3", "wav", "ogg", "m4a")
            "document" -> file.extension.lowercase() in arrayOf("pdf", "doc", "docx", "xls", "txt")
            else -> false
        }
    }
}

data class RecoverableFile(
    val path: String,
    val name: String,
    val size: Long,
    val lastModified: Long,
    val type: String
)
