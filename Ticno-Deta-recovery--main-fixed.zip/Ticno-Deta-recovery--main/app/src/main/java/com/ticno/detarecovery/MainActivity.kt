package com.ticno.recovery

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.Settings
import android.view.View
import android.widget.*
import androidx.appcompat.app.AppCompatActivity
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import java.io.File

class MainActivity : AppCompatActivity() {

    private lateinit var progressBar: ProgressBar
    private lateinit var recyclerView: RecyclerView
    private lateinit var adapter: VideoAdapter
    private val videoList = ArrayList<String>()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        progressBar = findViewById(R.id.progressBar)
        recyclerView = findViewById(R.id.recyclerView)
        val scanButton: Button = findViewById(R.id.scanButton)

        recyclerView.layoutManager = LinearLayoutManager(this)
        adapter = VideoAdapter(videoList)
        recyclerView.adapter = adapter

        scanButton.setOnClickListener {
            if (!Environment.isExternalStorageManager()) {
                val intent = Intent(Settings.ACTION_MANAGE_APP_ALL_FILES_ACCESS_PERMISSION)
                intent.data = Uri.parse("package:$packageName")
                startActivity(intent)
            } else {
                scanVideos()
            }
        }
    }

    private fun scanVideos() {
        videoList.clear()
        progressBar.visibility = View.VISIBLE

        Thread {
            val exDir = Environment.getExternalStorageDirectory()
            scanFolder(exDir)

            runOnUiThread {
                progressBar.visibility = View.GONE
                adapter.notifyDataSetChanged()
                Toast.makeText(this, "Scan complete: ${videoList.size} videos found", Toast.LENGTH_LONG).show()
            }
        }.start()
    }

    private fun scanFolder(dir: File) {
        val files = dir.listFiles() ?: return
        for (file in files) {
            if (file.isDirectory) {
                scanFolder(file)
            } else {
                if (file.extension.lowercase() in listOf("mp4", "3gp", "mkv", "avi")) {
                    videoList.add(file.absolutePath)
                }
            }
        }
    }
}
